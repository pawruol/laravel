Footer
<?php /**PATH C:\ospanel\domains\wepo\resources\views/parts/footer.blade.php ENDPATH**/ ?>